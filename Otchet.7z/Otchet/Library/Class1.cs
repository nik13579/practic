﻿using System;

namespace Library
{
    public class Class1
    {
        public static double sum(double a, double b)
        {
            return a + b;
        }
        public static double raz(double a, double b)
        {
            return a - b;
        }
        public static double proiz(double a, double b)
        {
            return a * b;
        }
        public static double del(double a, double b)
        {
            return a / b;
        }
        public static double step(double a, double b)
        {
            return Math.Pow(a, b);
        }
        public static double kor(double a, double b)
        {
            return Math.Pow(a, 1 / b);
        }
    }
    
}
